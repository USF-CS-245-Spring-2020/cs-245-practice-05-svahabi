import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 * MegaSort class which uses a quick sort algorithm to sort every value in a text file
 * This class may reference in-class materials, cs tutors, or other online sources/websites.
 */
public class MegaSort {

    /**
     * quick sort algorithm method which accepts the min and max values as well as the source array and runs quick sort on it
     * @param arr
     * @param start
     * @param end
     */
    void qSort(int arr[], int start, int end)
    {
        if (start < end)
        {

            int pi = partition(arr, start, end);

            qSort(arr, start, pi-1);
            qSort(arr, pi+1, end);
        }
    }

    /**
     * partition method which determines the partition in the array and adjusts the pivots when a certain limit has been reached
     * @param arr
     * @param start
     * @param end
     * @return
     */
    public int partition(int arr[], int start, int end)
    {
        int pivot = arr[end];
        int i = (start-1);
        for (int j=start; j<end; j++)
        {

            if (arr[j] < pivot)
            {
                i++;


                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }


        int temp = arr[i+1];
        arr[i+1] = arr[end];
        arr[end] = temp;

        return i+1;
    }

    /**
     * Sort method which creates a file reader and reads the file into a String array which is then converted into an integer array and sorted using quick sort.
     * @param file
     */
    public void mSort(File file) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line = reader.readLine();
            int size = 0;
            while (line != null) {
                size++;
                line = reader.readLine();
            }
            int i = 0;
            int[] arr = new int[size];
            String[] stringArr = new String[size];
            reader = new BufferedReader(new FileReader(file));
            line = reader.readLine();
            while (line != null) {
                stringArr[i] = line;
                line = reader.readLine();
                i++;
            }
            reader.close();
            for (int j = 0; j < arr.length; j++) {
                arr[j] = Integer.parseInt(stringArr[j]);
            }
            qSort(arr, 0, arr.length - 1);
            printArr(arr);
        }
        catch (IOException e) {
            System.out.println("File not found");
        }
    }


    /**
     * printArr method which uses a for-loop to iterate through each value in the array and prints it line by line
     * @param arr
     */
    void printArr(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }
    }

    /**
     * main method which creates an object of the mega sort class and passes the file to the sorting method
     * @param args
     */
    public static void main(String[] args) {
        MegaSort sort = new MegaSort();
        File file = new File("1m-ints.txt");
        sort.mSort(file);
    }

}

